# perfect_blue_ctf _2021

## **Redis**

Redis is an open source bsd in memory data structure store, used as a database, cache and message broker. Redis provides data structures such as strings, hashes, lists, sets and sorts.

**Exploit of Redis :**

- Redis has an exploit in **metasploit**
- name of exploit is **redis_unauth_exec**

## Vulnerability - check [here](https://snyk.io/vuln/npm:redis-commander:20180109)

- **Redis Commander** is Redis management tool written in node.js
- Affected version of this package are vulnerable to Reflected XSS