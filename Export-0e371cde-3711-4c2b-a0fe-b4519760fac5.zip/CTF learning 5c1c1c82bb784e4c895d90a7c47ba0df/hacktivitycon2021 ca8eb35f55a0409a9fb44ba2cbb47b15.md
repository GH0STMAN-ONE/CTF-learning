# hacktivitycon2021

#Tools **Sonic visualiser** and the file is with .wave extension #Tools **foremost** for extracting file #Tools **binwalk** #Tools **strings -n 10 | grep -i flag** #Tools **hexedit** #Tools **Stegsolve** #Tools **gif split** -online tool #Tools **barcode decoder** #Tools **Checksec** – to know protections on file